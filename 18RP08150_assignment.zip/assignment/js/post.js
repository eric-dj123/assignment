const API_URL = "http://localhost/assignment/api/post_one.php";
const API_URL_save = "http://localhost/assignment/api/save.php";
const API_BASE_URL = "http://localhost/assignment/";

window.onload = () => {
    getPost();
}

const getPostIdParam = () => {
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    return urlParams.get('id');
}

const getPost = () => {
    const url = `${API_URL}?id=${getPostIdParam()}`
    fetch(url, {
        method: 'GET'
    }).then((response)=>{
        return response.json();
    }).then((data)=>{
        buildPost(data);
    })
}

const buildPost = (data) => {
    console.log(data);
    const postDate = new Date((data.added_date)).toDateString();
    const postImage = API_BASE_URL + data.post_image;
    document.querySelector("header").style.backgroundImage = `url(${postImage})`;
    document.getElementById("individual-post-title").innerText = data.title;
    document.getElementById("individual-post-date").innerText =  `Published on ${postDate}`;
    document.getElementById("individual-post-content").innerText = data.content;
    document.getElementById("edit").setAttribute("href",API_BASE_URL+'edit-post.html?id='+data.id);
    document.getElementById("delete").setAttribute("onclick",'delete_post(\''+data.id+'\');');
}



function delete_post(p_id){
    var x = window.confirm("are you sure that you want to delete this post ?");
    if(x){
        let data = new FormData();
        data.append('id', p_id);
        data.append('delete', 'delete');

        fetch(API_URL_save, {
            method: 'POST',
            body: data
        }).then(()=>{
            setTimeout(()=>{
                window.location.href = "index.html";
            }, 1000)
        })
    }else{
        // canceled
    }
}