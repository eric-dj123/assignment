const API_URL_EDIT = "http://localhost/assignment/api/post_one.php";
const API_BASE_URL = "http://localhost/assignment/";

window.onload = () => {
    getPost();
}

const getPostIdParam = () => {
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    return urlParams.get('id');
}

const getPost = () => {
    const url = `${API_URL_EDIT}?id=${getPostIdParam()}`
    fetch(url, {
        method: 'GET'
    }).then((response)=>{
        return response.json();
    }).then((data)=>{
        buildPost(data);
    })
}

const buildPost = (data) => {
    console.log(data);
    const postDate = new Date((data.added_date)).toDateString();
    const postImage = API_BASE_URL + data.post_image;
    document.querySelector("header").style.backgroundImage = `url(${postImage})`;
    document.getElementById("form-post-id").value = data.id;
    document.getElementById("form-post-title").value = data.title;
    document.getElementById("form-post-content").value = data.content;
}

