<?php
	include 'index.php';
	if (isset($_GET) && isset($_GET['id'])) {
		echo json_encode(blog::blog_post($_GET['id'],['data']));
	}else{
		echo json_encode(array());
	}