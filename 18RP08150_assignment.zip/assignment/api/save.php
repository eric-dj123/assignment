<?php
	include 'index.php';
	if (isset($_POST) && isset($_POST['title'])) {
		if (isset($_POST['title']) && !empty("id") && !empty($_POST['content']) && is_array($_FILES) && count($_FILES) > 0) {
			extract($_POST);
			$file1 = my_form::upload("post-image");
			if (isset($file1['message']) && $file1['message'] == "ok") {
				$post_image = $file1['link'];
			}else{
				//exit("file upload went wrong try again later");
				$post_image = "";
			}
			$rt = new my_db();
			$tab = $rt->table("blog"); 
			if (empty($post_image)) {
				$ck = $rt->insert("UPDATE `blog` SET `title`=:title, `content`=:content, `post_image`=:post_image WHERE id=:id",[[':title',$title],[':content',$content],[':id',$id]]);
			}else{
				$ck = $rt->insert("UPDATE `blog` SET `title`=:title, `content`=:content, `post_image`=:post_image WHERE id=:id",[[':title',$title],[':content',$content],[':post_image',$post_image],[':id',$id]]);
			}
			
			if ($ck == "ok") {
				echo "done";exit();
			}else{
				exit("Something went Wrong please try again later");
			}
		}
	}
	if (isset($_POST) && isset($_POST['id'])) {
		if (isset($_POST['delete']) && !empty("id")) {
			extract($_POST);
			$rt = new my_db();
			$tab = $rt->table("blog"); 
			$dt = blog::blog_post($id,['data']);
				if (isset($dt['post_image'])) {
					$link = getcwd().DIRECTORY_SEPARATOR.'img'.DIRECTORY_SEPARATOR.rtrim(ltrim($dt['post_image'],'api'.DIRECTORY_SEPARATOR.'img'.DIRECTORY_SEPARATOR),'api'.DIRECTORY_SEPARATOR.'img'.DIRECTORY_SEPARATOR);
					// if (file_exists($link)) {
						unlink($link);
					// }
				}
			$ck = $rt->insert("DELETE FROM `blog` WHERE id=:id",[[':id',$id]]);
			
			if ($ck == "ok") {
				echo "done";exit();
			}else{
				exit("Something went Wrong please try again later");
			}
		}
	}