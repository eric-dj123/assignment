<?php
	include 'index.php';
	echo json_encode(blog::blog_post());