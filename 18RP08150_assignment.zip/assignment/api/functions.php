<?php
  define('base_path', '/assignment/');
  define('company', 'Blog_post');
  
  define("APP_NAME", "application");
  define('APP_MASK', 'application');
  define('currency', 'Frw');
  define('working_dev','dev');//prod in production // dev in development
  define('type', 'no');//secure in production // no in development

  define("APP_VERSION", "1.1");
  define('APP_PROGRAMMER', ['name'=>'','email'=>'me@gmail.com']);
  define('dbhost',"localhost");
  define('db',"blog");
  define('dbpass_preview', '');
  define('dbpass', '');
  define('dbusr', 'root');
  define('dbport', '33006');
	/**
	 * db execution
	 */
	class my_db
	{
		public $conn = "";
		function table($pref)
    {
      $table = array(
              "blog" => "blog",
            );
      return $table[$pref];
    }
    function __construct($connn='pdo')
    {
      if ($connn == "pdo") {
        $servername = dbhost;
        $username = dbusr; 
        $password = dbpass;
        $dbname = db;
        $port = dbport;
          try{
          $this->conn = new PDO("mysql:host=$servername;dbname=$dbname; charset=utf8;port=$port", $username, $password); 
          }
          catch(PDOException $ex){
            $this->conn = "error";
          }
      }
    }
    public function connection_check()
    {
      $cnn = $this->conn;
      if ($cnn == "error") {
        return false;
      }else{
        return true;
      }
    }
    public function last_id()
    {
      $con = $this->conn;
      $last_id = $con->lastInsertId();
      return $last_id;
    }
    public static function create_db($db='')
    {
      $retur = false;
      if (!empty($db)) {
        $servername = dbhost;
        $username = dbusr;
        $password = dbpass;
        $port = dbport;
        $conn = new PDO("mysql:host=$servername; charset=utf8;port=$port", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "CREATE DATABASE IF NOT EXISTS ".$db;
        $sanitise = explode(";", $sql);
        $query = "";
        if (isset($sanitise[0])) {
          $qq = explode(" ", $sql);
          if (isset($qq[0]) && $qq[0] == "CREATE" && isset($qq[1]) && $qq[1] == "DATABASE" ) {
            $query = $sanitise['0'];
          }
        }
        // use exec() because no results are returned
        //var_dump($query);exit();
        if ($conn->exec($query)) {
          $retur = true;
        }
      }
      return $retur;
    }
    function connect()
    {
      $conn = $this->conn;
      if(is_null($conn) || $conn===FALSE)
      {
          die('Rasms Internal error');
      }
      return $this->conn;
    }
		function select($query = "SELECT 1=1",$params = null)
		{
      //var_dump($query);
			try {
          if (is_string($this->conn)) {
            exit("db connection failed");
          }
			    $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			    $stmt = $this->conn->prepare($query);
			    if (is_array($params) && count($params) > 0) {
			     	foreach ($params as $pd) {
			     		if (!empty($pd)) {
			     			$regpd = $pd;
			     			if (is_array($regpd) && count($regpd)==2) {
			     				$stmt->bindParam($regpd[0], $regpd[1]);
			     			}
			     		}
			     	}
			     }
			    $stmt->execute();
			    $stmt->setFetchMode(PDO::FETCH_ASSOC);
			    $res = $stmt->fetchAll(); 
			}
			catch(PDOException $e) {
        $res = array();
        if (constant('working_dev') == 'dev') {
          $res = array("Error: ",$e->getMessage());
        }
			}
			return $res;
			$conn = null;
		}
    function insert($query,$params= null)
    {
      try {
        if (is_string($this->conn)) {
            exit("db connection failed");
          }

          $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          $stmt = $this->conn->prepare($query);
          if (is_array($params) && count($params) > 0) {
            foreach ($params as $pd) {
              if (!empty($pd)) {
                $regpd = $pd;
                if (is_array($regpd) && count($regpd)==2) {
                  $stmt->bindParam($regpd[0], $regpd[1]);
                }
              }
            }
           }
          $stmt->execute();
          $rett = "ok";
        }
      catch(PDOException $e)
          {
            if (constant('working_dev') == 'dev') {
              echo "error".$e->getMessage();
            }
            $rett = "no";
          }
      return $rett;
      $conn = null;
    }
    function exec($query="")
    {
      $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);
      $ret = "no";
      if ($this->conn->exec($query)) {
        $ret = "ok";
      }
      return $ret;
    }

	}

  /**
   * upload plugin
   */
  class my_form
  {
    
    function __construct()
    {
      // code...
    }
    public static function upload($file='',$dir='')
    {
          $dir2 = $dir;
          $dir = ($dir != '') ? $dir : getcwd().DIRECTORY_SEPARATOR."img".DIRECTORY_SEPARATOR ;
          $up_files_array = $_FILES[$file];
          $countfiles = (is_array($up_files_array)) ? count($up_files_array) : 1 ;;
          $files_array = array();
          //var_dump($up_files_array['tmp_name']);
          //exit();
            if (file_exists($up_files_array["tmp_name"])) {
              $file_type = $up_files_array["type"]; //returns the mimetype
              $allowed = array("image/jpeg", "image/gif", "image/png");
              if(!in_array($file_type, $allowed)) {
                exit("only images .jpeg, .gif, and .png Are allowed in this file upload");
              }else{
                $ckup="";
                // Check file size
                if ($up_files_array["size"] > 50000000) {
                    $ckup = 1;
                }

                $fileData = pathinfo(basename($up_files_array["name"]));
                $fileName = "file_"."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
                $regpath = __DIR__;
                $target_path = $dir.$fileName;
                while(file_exists($target_path))
                {
                    $fileName = "file_"."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
                  $regpath = __DIR__;
                  $target_path = $dir.$fileName;
                }
                if ($ckup == "") {
                  if (move_uploaded_file($up_files_array["tmp_name"], $target_path))
                  {
                    array_push($files_array, $fileName);
                  }
                }
              }
            }
          $reft = "";
          $exp = ".,*original_prod*.,";
          foreach ($files_array as $key) {
            $reft .= $exp.$key;
          }
          if (strlen($reft) > strlen($exp)) {
            $reft = substr($reft, strlen($exp));
          }
          $upphoto = explode($exp, $reft);
          $var = count($upphoto);
          $ret = array();
          if (isset($upphoto) && !empty($upphoto) && $var >= 0 && isset($upphoto[0]) && !empty($upphoto[0]) && strlen($upphoto[0]) > 25) {
              $ret['message'] = "ok";
              $ret['name'] = $reft;
              $ret['link'] = "api/img/".$reft;
              
          }else{
            $ret['message'] = "something went wrong try again later";
            $ret['name'] = "";
          }
          return $ret;
    }
  }