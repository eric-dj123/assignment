<?php
	//posts api
	//include functions
	include 'functions.php';

	/**
	 * posts class
	 */
	class blog
	{
	    public static function blog_post($l_id="",$param=[1])
	    {
	      $rt = new my_db();
	      $tab = $rt->table("blog");

	      $v_ref = array();
	      if (isset($param[0]) && $param[0] == 1) {
	        $v_ref = $rt->select("SELECT * FROM $tab WHERE id !='' ORDER BY added_date DESC");
	        return $v_ref;
	      }elseif (isset($param[0]) && $param[0] == "data") {
	        $retur = false;
	        $v_ref = $rt->select("SELECT * FROM $tab WHERE id = :id",[[":id",$l_id]]);
	        if (isset($v_ref[0]['id']) && !empty($v_ref[0]['id'])) {
	          $retur = $v_ref[0];
	        }
	        return $retur;
	      }
	    }
	}