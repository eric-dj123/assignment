<?php
	include 'index.php';
	if (isset($_POST) && isset($_POST['title'])) {
		if (isset($_POST['title']) && !empty($_POST['content']) && is_array($_FILES) && count($_FILES) > 0) {
			extract($_POST);
			$file1 = my_form::upload("post-image");
			if (isset($file1['message']) && $file1['message'] == "ok") {
				$post_image = $file1['link'];
			}else{
				exit("file upload went wrong try again later");
			}
			$rt = new my_db();
			$tab = $rt->table("blog"); 

			$ck = $rt->insert("INSERT INTO `blog` (`id`, `title`, `content`, `post_image`, `added_date`) VALUES (NULL, :title, :content, :post_image, CURRENT_DATE())",[[':title',$title],[':content',$content],[':post_image',$post_image]]);
			if ($ck == "ok") {
				echo "done";exit();
			}else{
				exit("Something went Wrong please try again later");
			}
		}
	}